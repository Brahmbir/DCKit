extends HBoxContainer

#  SIGNALS

signal focus_changed(has_focus: bool)

signal command_submitted(raw: String)
signal text_changed(raw: String)
signal abort_requested

## Fired on every text change AND every caret movement.
## This is the single source of truth for the hint system.
## direction: -1 = previous, +1 = next
signal suggestion_navigate(direction: int)
signal suggestion_accept

## Carries both the full text and the caret column so the hint provider
## can re-analyse from the correct position without a separate getter call.
## Fired by: _on_text_changed, apply_suggestion, _set_text (history nav),
##           _process (caret movement with no text change).
signal input_state_changed(text: String, caret_pos: int)

#  EXPORTS
@export_group("shortcuts", "sct")
@export var sct_hst_previous        : Shortcut = _get_default_sct_hst_previous()
@export var sct_hst_next            : Shortcut = _get_default_sct_hst_next()
@export var sct_hst_prefix_previous : Shortcut = _get_default_sct_hst_prefix_previous()
@export var sct_hst_prefix_next     : Shortcut = _get_default_sct_prefix_hst_next()
@export var sct_suggestion_accept   : Shortcut = _get_default_sct_suggestion_accept()
@export var sct_suggestion_previous : Shortcut = _get_default_sct_suggestion_previous()
@export var sct_suggestion_next     : Shortcut = _get_default_sct_suggestion_next()

#  NODE REFS

@onready var button           : Button         = $HBoxContainer/AspectRatioContainer/Button
@onready var line_edit        : LineEdit       = $HBoxContainer/LineEdit
@onready var masked_icon_panel: MaskedIconPanel = $HBoxContainer/AspectRatioContainer/Button/MaskedIconPanel

@onready var label: Label = $MarginContainer/Label
#region
func tween_label_variation(
	from_variation: String,
	to_variation: String,
	duration := 0.1
) -> void:
	#_accent_color = get_theme_color("accent_colour","Consts")
	#_normal_color = get_theme_color("border_colour","Consts")

	var from_color := get_theme_color(
		"font_color",
		from_variation
	)

	var to_color := get_theme_color(
		"font_color",
		to_variation
	)

	# Create local override so only this label animates
	label.add_theme_color_override(
		"font_color",
		from_color
	)

	var tween := create_tween()

	tween.tween_method(
		func(c: Color):
			label.add_theme_color_override(
				"font_color",
				c
			),
		from_color,
		to_color,
		duration
	)

	# Snap to final variation at end
	tween.finished.connect(
		func():
			label.remove_theme_color_override(
				"font_color"
			)

			label.theme_type_variation = (
				to_variation
			)
	)
#endregion

#  STATE

enum State { IDLE, BUSY }
var _state : State = State.IDLE

#  HISTORY
#
#  _history         — submitted commands, oldest at index 0
#  _history_index   — current browse position; -1 means "not browsing"
#  _draft           — the text the user was typing before browsing started;
#                     restored when they navigate back past the end
#
#  Prefix history:
#  _prefix          — text captured when Ctrl+UP is first pressed
#  _prefix_matches  — filtered view of _history for that prefix
#  _prefix_index    — browse position within _prefix_matches; -1 = not browsing
var _history        : Array[String] = []
var _history_index  : int           = -1
var _draft          : String        = ""

var _prefix         : String        = ""
var _prefix_matches : Array[String] = []
var _prefix_index   : int           = -1

const _DEBOUNCE_SEC : float = 0.1
var   _last_submit  : float = 0.0

#  CARET TRACKING
#  LineEdit has no caret_moved signal in Godot 4, so we poll every frame.
#  Only fires input_state_changed when the caret actually moves and the
#  field is focused, so overhead is negligible.
var _last_caret_pos : int = -1


#  LIFECYCLE

func _ready() -> void:
	# Intercept keyboard events on the LineEdit BEFORE it handles them.
	# Connecting here lets us call accept_event() to suppress LineEdit's
	# default behaviour (e.g. UP/DOWN moving the caret to start/end of text).
	line_edit.gui_input.connect(_on_line_edit_input)

	line_edit.text_changed.connect(_on_text_changed)
	line_edit.text_submitted.connect(_on_submit)
	
	line_edit.focus_entered.connect(_on_focus_entered)
	line_edit.focus_exited.connect(_on_focus_exited)
	
	button.pressed.connect(_on_button_pressed)
	
	masked_icon_panel.accent_color = get_theme_color("accent_colour","Consts")

	_set_state(State.IDLE)


func _process(_delta: float) -> void:
	# Only poll when the field is focused and IDLE — no point updating hints
	# while busy or when the user isn't even typing.
	if _state == State.BUSY or not line_edit.has_focus():
		return

	var pos : int = line_edit.caret_column
	if pos != _last_caret_pos:
		_last_caret_pos = pos
		input_state_changed.emit(line_edit.text, pos)


#  PUBLIC  — called by the container

func set_busy(is_busy: bool) -> void:
	_set_state(State.BUSY if is_busy else State.IDLE)


## Replaces the current line edit text with the accepted suggestion
## and positions the caret at the end.
func apply_suggestion(text: String) -> void:
	_set_text(text)
	line_edit.caret_column = text.length()
	# _set_text bypasses _on_text_changed, so we push the state manually.
	_emit_input_state()
	focus()


func get_caret_pos() -> int:
	return line_edit.caret_column


func focus() -> void:
	line_edit.grab_focus()

#region LINE EDIT INPUT

func _on_line_edit_input(event: InputEvent) -> void:
	# Prefix history — Ctrl+UP / Ctrl+DOWN
	if _shortcut_pressed(event, sct_hst_prefix_previous):
		_browse_prefix(-1)
		line_edit.accept_event()
		return

	if _shortcut_pressed(event, sct_hst_prefix_next):
		_browse_prefix(1)
		line_edit.accept_event()
		return

	# Suggestion navigation — emitted upward, container decides what to tell SuggestionRow
	if _shortcut_pressed(event, sct_suggestion_accept):
		suggestion_accept.emit()
		line_edit.accept_event()
		return

	if _shortcut_pressed(event, sct_suggestion_previous):
		suggestion_navigate.emit(-1)
		line_edit.accept_event()
		return

	if _shortcut_pressed(event, sct_suggestion_next):
		suggestion_navigate.emit(1)
		line_edit.accept_event()
		return

	# Plain history — UP / DOWN
	# accept_event() stops LineEdit from moving the caret to start/end of text.
	if _shortcut_pressed(event, sct_hst_previous):
		_browse_history(-1)
		line_edit.accept_event()
		return

	if _shortcut_pressed(event, sct_hst_next):
		_browse_history(1)
		line_edit.accept_event()
		return

#endregion

#region HISTORY NAVIGATION

## Navigates the full history. direction: -1 = older, +1 = newer.
func _browse_history(direction: int) -> void:
	if _history.is_empty():
		return

	# First keypress — save whatever the user was typing.
	if _history_index == -1:
		_draft = line_edit.text

	var next : int = _history_index + direction

	if next < 0:
		# Already at the oldest entry — clamp, do nothing.
		return

	if next >= _history.size():
		# Navigated past the newest entry — restore the draft.
		_history_index = -1
		_set_text(_draft)
		return

	_history_index = next
	# History is stored oldest-first. Index 0 = oldest.
	# Navigating "previous" (direction -1) counts upward from the end.
	var history_pos : int = (_history.size() - 1) - _history_index
	_set_text(_history[history_pos])


## Navigates history filtered by the prefix captured on first keypress.
## direction: -1 = older match, +1 = newer match.
func _browse_prefix(direction: int) -> void:
	if _history.is_empty():
		return

	# First Ctrl+UP press — capture the current text as the filter prefix
	# and build the filtered list once.
	if _prefix_index == -1:
		_draft          = line_edit.text
		_prefix         = line_edit.text
		_prefix_matches = _history.filter(
			func(cmd: String) -> bool:
				return cmd.begins_with(_prefix) and cmd != _prefix
		)
		# Reverse so index 0 is the most recent match.
		_prefix_matches.reverse()

	if _prefix_matches.is_empty():
		return

	var next : int = _prefix_index + direction

	if next < 0:
		# Past the oldest match — clamp.
		return

	if next >= _prefix_matches.size():
		# Past the newest match — restore draft and exit prefix mode.
		_prefix_index = -1
		_set_text(_draft)
		return

	_prefix_index = next
	_set_text(_prefix_matches[_prefix_index])

#endregion

#region SUBMIT

func _on_submit(raw: String) -> void:
	if _state == State.BUSY:
		return

	var now : float = Time.get_unix_time_from_system()
	if now - _last_submit < _DEBOUNCE_SEC:
		return

	var text : String = raw.strip_edges()
	if text.is_empty():
		return

	_last_submit = now

	# Add to history. Skip duplicates of the most recent entry.
	if _history.is_empty() or _history.back() != text:
		_history.append(text)

	# Reset all history browse state before clearing the field.
	_reset_history_state()
	line_edit.clear()

	command_submitted.emit(text)

#endregion

#region SIGNAL HANDLERS

func _on_focus_entered() -> void:
	tween_label_variation("SimpleLabel","Label")
	focus_entered.emit()
	focus_changed.emit(true)


func _on_focus_exited() -> void:
	tween_label_variation("Label","SimpleLabel")
	focus_exited.emit()
	focus_changed.emit(false)

func _on_button_pressed() -> void:
	if _state == State.BUSY:
		abort_requested.emit()
	else:
		_on_submit(line_edit.text)


func _on_text_changed(new_text: String) -> void:
	# Typing cancels history browsing — user is writing something new.
	_reset_history_state()
	text_changed.emit(new_text)
	# Sync caret tracker so _process doesn't double-fire on the same frame.
	_last_caret_pos = line_edit.caret_column
	input_state_changed.emit(new_text, _last_caret_pos)

#endregion

#region INTERNALS

func _set_state(s: State) -> void:
	_state = s
	masked_icon_panel.is_off = (s != State.BUSY)
	line_edit.editable = s == State.IDLE


## Sets line edit text without triggering _on_text_changed so history
## browsing does not reset itself mid-navigation.
## Emits input_state_changed explicitly so the hint system stays in sync.
func _set_text(text: String) -> void:
	line_edit.text_changed.disconnect(_on_text_changed)
	line_edit.text = text
	line_edit.caret_column = text.length()
	line_edit.text_changed.connect(_on_text_changed)
	# History navigation changed the field — push the new state to hints.
	_emit_input_state()


## Clears all history and prefix browse state back to defaults.
func _reset_history_state() -> void:
	_history_index  = -1
	_draft          = ""
	_prefix         = ""
	_prefix_matches = []
	_prefix_index   = -1


## Single place that emits input_state_changed and keeps _last_caret_pos synced.
func _emit_input_state() -> void:
	_last_caret_pos = line_edit.caret_column
	input_state_changed.emit(line_edit.text, _last_caret_pos)

#endregion

#region DEFAULT SHORTCUTS

func _get_default_sct_hst_prefix_previous() -> Shortcut:
	return _make_shortcut(KEY_UP, true)
func _get_default_sct_prefix_hst_next() -> Shortcut:
	return _make_shortcut(KEY_DOWN, true)
func _get_default_sct_hst_previous() -> Shortcut:
	return _make_shortcut(KEY_UP)
func _get_default_sct_hst_next() -> Shortcut:
	return _make_shortcut(KEY_DOWN)
func _get_default_sct_suggestion_accept() -> Shortcut:
	return _make_shortcut(KEY_ENTER, true)
func _get_default_sct_suggestion_previous() -> Shortcut:
	return _make_shortcut(KEY_LEFT, true, false, true)
func _get_default_sct_suggestion_next() -> Shortcut:
	return _make_shortcut(KEY_RIGHT, true, false, true)

#endregion

#region HELPERS

func _shortcut_pressed(event: InputEvent, shortcut: Shortcut) -> bool:
	return (
		event is InputEventKey
		and event.pressed
		and shortcut.matches_event(event)
	)


func _make_shortcut(
		key   : Key,
		ctrl  := false,
		shift := false,
		alt   := false) -> Shortcut:
	var key_event := InputEventKey.new()
	key_event.keycode                      = key
	key_event.ctrl_pressed                 = ctrl
	key_event.shift_pressed                = shift
	key_event.alt_pressed                  = alt
	key_event.command_or_control_autoremap = true
	var shortcut    := Shortcut.new()
	shortcut.events  = [key_event]
	return shortcut

#endregion
